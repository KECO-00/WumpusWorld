import agent
import world

print(world.world.sim(agent.Agent()))



